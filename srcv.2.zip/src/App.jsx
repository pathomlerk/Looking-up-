import './App.css'
import Nav from './components/Nav/Nav';
import Product from './components/Product/Product';

function App() {

  return (
    <>
      <Nav />
      <Home />
      <Product />
    </>
  )
}

export default App
