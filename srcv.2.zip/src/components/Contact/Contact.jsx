import React from 'react'
import Nav from '../Nav/Nav'
import './ContactStyle.css'

function Contact() {
  return (
    <section id='con'>
    {/*<Nav/>*/}
    <div className='--contact'>Contact</div>
    <div className='sofa'></div>
        <div className='e9'></div>
        <div className='e10'></div>
        <div className='e11'></div>
        <div className='e5'></div>
        <div className='e7'></div>
        <div className='e14'></div>
        <div className='e13'></div>
        <div className='photoroom'></div>
    </section>
  )
}

export default Contact