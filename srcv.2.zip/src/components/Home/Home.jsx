import React from 'react'
import Nav from '../Nav/Nav'
import './HomeStyle.css'
import { ImSearch } from "react-icons/im";
import { Link } from 'react-router-dom'

function Home() {
  return (
    <>
    <Nav/>
    <section id='home'>
      <div className='-search'>
        <div className='-search-box'>
          <input type='text' className='-search-input'/>
        </div>
          <div className='--btn'><ImSearch /></div>
      </div>
              <h2>Find your own skin color</h2>
          <div>
          <Link to='/quiz' className='-tap'>Tap to start</Link>
        </div>
      <div className='-color'>
        <div className='sofa'></div>
        <div className='e9'></div>
        <div className='e10'></div>
        <div className='e11'></div>
        <div className='e5'></div>
        <div className='e7'></div>
        <div className='e12'></div>
        <div className='photoroom'></div>
      </div>
    </section>
    </>
    
  )
}

export default Home