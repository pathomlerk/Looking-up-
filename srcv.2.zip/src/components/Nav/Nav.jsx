import React from 'react'
import { Link } from 'react-router-dom'
import './NavStyle.css'

function Nav() {
  return (
    <section id='Nav'>
      <div className='-center'>
        <div className='-menu'>
          <div className='-home'><Link to='/'>Home</Link></div>
          <div className='-style'><Link to='/style'>Style</Link></div>
          <div className='-product'><Link to='/product'>Product</Link></div>
          <div className='-contact'><Link to='/contact'>Contact</Link></div>
        </div>
      </div>

      <div className='-end'>
        <div className='-end-item1'>
          <Link to='/login'>Log in</Link>
        </div>
        <div className='-end-item3'>|</div>
        <div className='-end-item2'>
          <Link to='/signup'>Sign up</Link>
        </div>
      </div>
    </section>
  );
}

export default Nav;
