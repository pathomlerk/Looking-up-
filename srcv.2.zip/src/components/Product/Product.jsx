import React from 'react';
import './ProductStyle.css';
import { Link } from 'react-router-dom';
import { BiSearchAlt } from 'react-icons/bi';
import { BsCart2 } from "react-icons/bs";
import { IoMdNotificationsOutline } from "react-icons/io";
import { IoHelpCircleOutline } from "react-icons/io5";
import { FaUserCircle } from "react-icons/fa";


function Product() {
  return (
    <>
      {/* <Navbar /> */}
      <div className='product'>
        <div>Product</div>
        <div className='-left'>
          <div className='menu-help'>
            <a href='Noti'><IoMdNotificationsOutline className='-icon'/>Notification</a>
            <a href='help'><IoHelpCircleOutline className='-icon'/>Help</a>
            <a href='profile'><FaUserCircle className='-icon'/>User</a>
          </div>
        </div>

        <div className='search'>
          <div className='search-box'>
            <input type='text' className='SearchProduct' />
            <div className='-btn'><BiSearchAlt className='--icon'/></div>
          </div>
          <div className='--btn'><BsCart2 className='--icon'/></div>
        </div>

        <div className='promote'>
          <div className='pic-1'><img src="https://via.placeholder.com/290x219" alt=""/></div>
          <div className='pic-2'><img src='https://via.placeholder.com/630x334' alt=''/></div>
        </div>

        <h4 className='topic-categories'>CATEGORIES</h4>
          <div className='categories'>
            <div className='image-1'>
              <img src="https://via.placeholder.com/156x139" alt="" />
              <img src="https://via.placeholder.com/156x139" alt="" />
              <img src="https://via.placeholder.com/156x139" alt="" />
              <img src="https://via.placeholder.com/156x139" alt="" />
              <img src="https://via.placeholder.com/156x139" alt="" />
            </div>

            <div className='image-2'>
              <img src="https://via.placeholder.com/156x139" alt="" />
              <img src="https://via.placeholder.com/156x139" alt="" />
              <img src="https://via.placeholder.com/156x139" alt="" />
              <img src="https://via.placeholder.com/156x139" alt="" />
              <img src="https://via.placeholder.com/156x139" alt="" />
            </div>
          </div>
      

          <h4 className='topic-daily'>DAILY DISCOVER</h4>
            <div className='line'></div>
              <div className='daily'>
                <div className='pick-1'>
                  <img src="https://via.placeholder.com/287x270" alt="" />
                  <img src="https://via.placeholder.com/287x270" alt="" />
                  <img src="https://via.placeholder.com/287x270" alt="" />
                </div>
                <div className='pick-2'>
                  <img src="https://via.placeholder.com/287x270" alt="" />
                  <img src="https://via.placeholder.com/287x270" alt="" />
                  <img src="https://via.placeholder.com/287x270" alt="" />
                </div>
                <div className='pick-3'>
                  <img src="https://via.placeholder.com/287x270" alt="" />
                  <img src="https://via.placeholder.com/287x270" alt="" />
                  <img src="https://via.placeholder.com/287x270" alt="" />
                </div>
                <div className='pick-4'>
                  <img src="https://via.placeholder.com/287x270" alt="" />
                  <img src="https://via.placeholder.com/287x270" alt="" />
                  <img src="https://via.placeholder.com/287x270" alt="" />
                </div>
                <div className='pick-5'>
                  <img src="https://via.placeholder.com/287x270" alt="" />
                  <img src="https://via.placeholder.com/287x270" alt="" />
                  <img src="https://via.placeholder.com/287x270" alt="" />
                </div>
              </div>
        </div>
    </>
  );
}

export default Product;
