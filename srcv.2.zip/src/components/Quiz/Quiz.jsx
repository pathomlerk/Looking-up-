import React from 'react'
import './QuizStyle.css'
import { Link } from 'react-router-dom'

const Quiz = () => {
  return (
    <div className='-quiz'>
        <h2>สีเส้นเลือดที่ข้อมือของคุณเป็นสี ?</h2>
      <div className='-ans'>
        <ul>
            <li>สีเขียว</li>
            <li>สีม่วง</li>
            <li>สีน้ำเงินเขียว</li>
        </ul>
      </div>
        <div className='-next'>
          <Link to='/quiz2'><button>Next</button></Link>
        </div>
        <div className="-all">คำถาม 1 ใน 3</div>
        <div className='e18'></div>
        <div className='e15'></div>
        <div className='e21'></div>
        <div className='e20'></div>
        <div className='e22'></div>
        <div className='e19'></div>
        <div className='e23'></div>
    </div>
  )
}

export default Quiz