import React from 'react'
import './QuizStyle.css'
import { Link } from 'react-router-dom'

const Quiz = () => {
  return (
    <div className='-quiz'>
        <h2>สีผิวของคุณหลังโดนแดด ? ?</h2>
      <div className='-ans'>
        <ul>
            <li>โดนแดดแล้วผิวคล้ำ</li>
            <li>โดนแดดแล้วผิวเป็นสีแดง</li>
        </ul>
      </div>
        <div className='-next'>
          <Link to='/quiz3'><button>Next</button></Link>
        </div>
        <div className="-all">คำถาม 2 ใน 3</div>
        <div className='e18'></div>
        <div className='e15'></div>
        <div className='e21'></div>
        <div className='e20'></div>
        <div className='e22'></div>
        <div className='e19'></div>
        <div className='e23'></div>
    </div>
  )
}

export default Quiz