import React from 'react'
import './QuizStyle.css'
import { Link } from 'react-router-dom'

const Quiz = () => {
  return (
    <div className='-quiz'>
        <h2>เทียบสีเครื่องประดับไหนแล้วดูผ่อง</h2>
      <div className='-ans'>
        <ul>
            <li>ใส่เครื่องประดับทองแล้วดูผ่อง</li>
            <li>ใส่เครื่องประดับเงินแล้วดูผ่อง</li>
        </ul>
      </div>
        <button>Next</button>
        <div className="-all">คำถาม 3 ใน 3</div>
        <div className='e18'></div>
        <div className='e15'></div>
        <div className='e21'></div>
        <div className='e20'></div>
        <div className='e22'></div>
        <div className='e19'></div>
        <div className='e23'></div>
    </div>
  )
}

export default Quiz