import React from 'react'
import Nav from '../Nav/Nav'
import './Styletone.css'

function Style() {
  return (
  <>
    {/*<Nav/>*/}
    <section id='style'>
      <div className='-header'>Personal Tone</div>
      <div className='-tone'>
        <div className='-spring'>Ssssssssssssssssssssssssssssss</div>
        <div className='-autumn'>A</div>
        <div className='-summer'>Sum</div>
        <div className='-winter'>W</div>
      </div>
    </section>
  </>
  )
}

export default Style